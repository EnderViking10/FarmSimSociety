-- clientFunctions.lua

function updateFarmStatus()
    -- Update the farm's status (money, tasks, etc.)
    print("Farm status updated.")
end

function showAuctionUpdates()
    -- Show auction bid updates to clients
    print("Auction updates shown.")
end

function displayRepairStatus()
    -- Show repair status to clients
    print("Repair status displayed.")
end

return {updateFarmStatus, showAuctionUpdates, displayRepairStatus}
