-- syncVehicleRepairs.lua

function syncVehicleRepairs:sync()
    -- Sync repair statuses across clients
    print("Syncing vehicle repairs...")
end

return syncVehicleRepairs
