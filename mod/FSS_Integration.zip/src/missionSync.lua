local MissionSync = {}
local http = require("socket.http")
local json = require("json")

-- Add a contract to the game
function MissionSync.addContractToGame(data)
    ContractManager.createContract(data)
end

-- Notify website of accepted contracts
function MissionSync.notifyWebsiteOnContractAccepted(contractId, playerName)
    local contract = g_missionManager:getMissionById(contractId)

    if contract then
        local url = "https://farmsimsociety.com/api/contractUpdate"
        local requestBody = {
            id = contract.id,
            status = "Accepted",
            player = playerName
        }

        local response = {}
        local _, code = http.request {
            url = url,
            method = "POST",
            headers = {
                ["Content-Type"] = "application/json",
                ["Content-Length"] = tostring(#json.encode(requestBody))
            },
            source = ltn12.source.string(json.encode(requestBody)),
            sink = ltn12.sink.table(response)
        }

        if code == 200 then
            print("Contract " .. contractId .. " accepted by " .. playerName .. " and synced to website.")
        else
            print("Error syncing contract " .. contractId .. " to website. HTTP code: " .. code)
        end
    else
        print("Error: Contract " .. contractId .. " not found.")
    end
end

return MissionSync
