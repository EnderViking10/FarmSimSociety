-- syncFarmTasks.lua

function syncFarmTasks:sync()
    -- Synchronize tasks like adding money or repairs across clients
    print("Syncing farm tasks across multiplayer...")
end

return syncFarmTasks
