local socketserver = require("socketserver")
local json = require("json")

local HttpServer = {}

function HttpServer.start()
    local server = socketserver.new()
    
    server:route("/postContract", function(request, response)
        local contractData = json.decode(request.body)
        
        if contractData then
            MissionSync.addContractToGame(contractData)
            response.statusCode = 200
            response.body = "Contract added to the game."
        else
            response.statusCode = 400
            response.body = "Invalid contract data."
        end
        
        return response
    end)

    server:run(8080)
    print("HTTP server started on port 8080")
end

return HttpServer
