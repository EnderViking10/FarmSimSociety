-- syncAuctionBids.lua

function syncAuctionBids:sync()
    -- Sync auction bids across players
    print("Syncing auction bids...")
end

return syncAuctionBids
