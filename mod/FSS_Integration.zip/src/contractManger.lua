local ContractManager = {}

function ContractManager.createContract(data)
    local missionType = g_missionManager:getMissionTypeByName(data.type)
    local field = g_fieldManager:getFieldById(data.field)

    if missionType and field then
        local contract = {
            id = data.id,
            field = field,
            type = missionType,
            reward = data.reward,
            status = AbstractMission.STATUS_OFFERED,
            farmId = data.farmId or 0
        }

        g_missionManager:addMission(contract)
        print("Contract created: " .. data.type .. " on Field " .. data.field)
    else
        print("Error: Invalid mission type or field ID.")
    end
end

return ContractManager