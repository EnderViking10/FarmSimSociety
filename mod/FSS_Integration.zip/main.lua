local modDirectory = g_currentModDirectory
local modName = g_currentModName
local HttpServer = require("scripts.httpServer")
local ContractManager = require("scripts.contractManager")
local MissionSync = require("scripts.missionSync")

local autoFarmManagerInterval = 60  -- Set the interval for auto farm manager tasks (in seconds)

-- Discord webhook URL (replace with your actual Discord webhook URL)
local discordWebhookUrl = "https://discord.com/api/webhooks/1318016706479657000/WzdU6xf-xXCgZX0zHWzH8gPkHmq_JNjuKrQNje5D74r4f5hxMXCzOk-4WqWwihN5vols"

-- Utility function to load a JSON file (Database Simulation)
local function loadJsonFile(filePath)
    local file = io.open(filePath, "r")
    if file then
        local content = file:read("*all")
        file:close()
        return json.decode(content)
    else
        print("Error: Could not open file at " .. filePath)
        return nil
    end
end
-- Event listener for when a contract is accepted
local function onContractAccepted(contractId, playerName)
    MissionSync.notifyWebsiteOnContractAccepted(contractId, playerName)
end

-- Initialize the mod
local function init()
    -- Start HTTP server
    HttpServer.start()

    -- Register event listener
    MissionManager.addContractAcceptedListener(onContractAccepted)

    print("FarmSim Society mod initialized.")
end

-- Run initialization
init()
-- Function to send a message to Discord via webhook
local function sendToDiscord(message)
    local data = {
        content = message,
        username = "Auto Farm Manager",
    }

    local jsonData = json.encode(data)

    -- Sending data to Discord Webhook (using HTTP request)
    local response = HttpRequest.post(discordWebhookUrl, jsonData, "application/json")
    if response then
        print("Discord message sent successfully.")
    else
        print("Error: Could not send Discord message.")
    end
end

-- Log maintenance events
local function logMaintenance(vehicle, status)
    local filePath = getUserProfileAppPath() .. "modSettings/FarmSimSociety/maintenance_log.txt"
    local file = io.open(filePath, "a")
    if file then
        local logEntry = string.format(
            "[%s] Vehicle '%s' (%s) - Status: %s\n",
            os.date("%Y-%m-%d %H:%M:%S"),
            vehicle:getFullName(),
            vehicle.configFileName,
            status
        )
        file:write(logEntry)
        file:close()
        print("Maintenance log updated:", logEntry)
    else
        print("Error: Could not write to maintenance log file.")
    end
end
-- Include vehicle repair system
dofile("scripts/vehicleRepairSystem.lua")

-- Initialize player data
local playerMoney = 1000  -- Example starting money
local isAdmin = false     -- Admin status (set dynamically)
local landOwnership = {}  -- Tracks land ownership {landId = playerId}
local playerNames = {}    -- Maps player IDs to usernames {playerId = username}

-- Admin commands for managing player money
function adminAddMoney(amount)
    if not isAdmin then
        showMessage("You do not have permission to use this command.")
        return
    end
    playerMoney = playerMoney + amount
    showMessage("Added $" .. amount .. ". Current balance: $" .. playerMoney)
    updateRepairUI()
end

function adminRemoveMoney(amount)
    if not isAdmin then
        showMessage("You do not have permission to use this command.")
        return
    end
    if playerMoney >= amount then
        playerMoney = playerMoney - amount
        showMessage("Removed $" .. amount .. ". Current balance: $" .. playerMoney)
        updateRepairUI()
    else
        showMessage("Insufficient funds to remove that amount.")
    end
end

-- Banking system: Send money to a bank account via a website
function sendMoneyToBank(amount)
    if playerMoney < amount then
        showMessage("Insufficient funds to send that amount.")
        return
    end

    local bankUrl = "https://farmsimsociety.com/api/transfer"  -- Replace with the actual bank API URL
    local postData = {
        playerId = getPlayerId(),  -- Replace with actual function to get player's ID
        amount = amount
    }

    sendHttpRequest("POST", bankUrl, postData, function(response)
        if response.success then
            playerMoney = playerMoney - amount
            showMessage("Successfully sent $" .. amount .. " to your bank account.")
            updateRepairUI()
        else
            showMessage("Failed to send money to the bank: " .. response.error)
        end
    end)
end

-- Admin commands for land ownership management
function setLandOwnership(landId, playerId)
    if not isAdmin then
        showMessage("You do not have permission to use this command.")
        return
    end

    if landOwnership[landId] then
        showMessage("Land ID " .. landId .. " is already owned by " .. getPlayerName(landOwnership[landId]))
    else
        landOwnership[landId] = playerId
        showMessage("Land ID " .. landId .. " is now owned by " .. getPlayerName(playerId))
    end
end

function revokeLandOwnership(landId)
    if not isAdmin then
        showMessage("You do not have permission to use this command.")
        return
    end

    if landOwnership[landId] then
        local previousOwner = landOwnership[landId]
        landOwnership[landId] = nil
        showMessage("Land ID " .. landId .. " ownership has been revoked from " .. getPlayerName(previousOwner))
    else
        showMessage("Land ID " .. landId .. " is not owned by anyone.")
    end
end

function transferLandOwnership(landId, newPlayerId)
    if not isAdmin then
        showMessage("You do not have permission to use this command.")
        return
    end

    if landOwnership[landId] then
        local previousOwner = landOwnership[landId]
        landOwnership[landId] = newPlayerId
        showMessage("Land ID " .. landId .. " ownership transferred from " .. getPlayerName(previousOwner) .. " to " .. getPlayerName(newPlayerId))
    else
        showMessage("Land ID " .. landId .. " is not owned. Set ownership first.")
    end
end

-- Display land ownership
function displayLandOwnership()
    print("Land Ownership Overview:")
    for landId, playerId in pairs(landOwnership) do
        print("Land ID: " .. landId .. " | Owner: " .. (getPlayerName(playerId) or "Unknown"))
    end
end

-- Get player name by ID
function getPlayerName(playerId)
    return playerNames[playerId] or ("Player " .. playerId) -- Fallback if username is not found
end

-- Update repair UI
function updateRepairUI()
    local costText = GUI.getElementByName("repairCostText")
    if costText then
        costText.text = "Current Balance: $" .. playerMoney
    end
end

-- Display messages to the player
function showMessage(message)
    print(message) -- Replace with in-game messaging system if available
end

-- Example HTTP POST request function
function sendHttpRequest(method, url, data, callback)
    Http.post(url, data, function(response)
        if response and response.status == 200 then
            callback({ success = true, data = response.body })
        else
            callback({ success = false, error = response.error or "Unknown error" })
        end
    end)
end

-- Initialize the game
function onInit()
    loadRepairGUI() -- Load repair GUI
    isAdmin = checkIfAdmin(getPlayerId()) -- Dynamically set admin status
    initializeLandOwnership() -- Initialize land ownership
    initializePlayerNames() -- Initialize player names
    displayLandOwnership() -- Show land ownership to all players
end

-- Initialize land ownership data
function initializeLandOwnership()
    landOwnership = {}
end

-- Initialize player name data
function initializePlayerNames()
    playerNames = {
        [1] = "FarmerJohn",
        [2] = "TractorQueen",
        [3] = "FieldMaster",
    }
end

-- Check if a player is an admin
function checkIfAdmin(playerId)
    return true -- Example: all players are admins (replace with actual logic)
end

-- Command handler
function onCommand(command, params)
    if command == "addmoney" then
        adminAddMoney(tonumber(params[1]))
    elseif command == "removemoney" then
        adminRemoveMoney(tonumber(params[1]))
    elseif command == "sendtobank" then
        sendMoneyToBank(tonumber(params[1]))
    elseif command == "setland" then
        setLandOwnership(tonumber(params[1]), tonumber(params[2]))
    elseif command == "revokeland" then
        revokeLandOwnership(tonumber(params[1]))
    elseif command == "transferland" then
        transferLandOwnership(tonumber(params[1]), tonumber(params[2]))
    else
        showMessage("Unknown command: " .. command)
    end
end

-- Run initialization
onInit()


-- Auto Farm Manager: Handles periodic tasks for all farms
local function autoFarmManager()
    print("Auto Farm Manager: Executing scheduled tasks...")

    -- Simulate loading farms from a database (file or database connection)
    local farmsDatabase = loadJsonFile(getUserProfileAppPath() .. "modSettings/FarmSimSociety/farmDatabase.json")

    -- Iterate over all farms and perform tasks
    for _, farm in ipairs(g_farmManager:getFarms()) do
        -- Check if the farm name exists in the "database"
        for _, dbFarm in ipairs(farmsDatabase) do
            if farm.name == dbFarm.name then
                -- Farm is in the database, perform automated tasks
                print("Farm matched with database:", farm.name)
                
                -- Add money to the farm (customize this logic)
                local farmMoneyAddAmount = dbFarm.moneyAmount or 10000
                farm.money = farm.money + farmMoneyAddAmount
                print(string.format("Added %d money to farm '%s'. New balance: %d", farmMoneyAddAmount, farm.name, farm.money))

                -- Send a notification to Discord
                sendToDiscord(string.format("Farm '%s' auto-management executed. Money added: %d", farm.name, farmMoneyAddAmount))

                -- Perform maintenance check and repair on vehicles
                for _, vehicle in ipairs(farm.vehicles) do
                    if vehicle:getRepairNeeds() > 0 then
                        vehicle:repair()
                        logMaintenance(vehicle, "repaired successfully")
                        print(string.format("Repaired vehicle '%s'.", vehicle:getFullName()))
                        sendToDiscord(string.format("Vehicle '%s' repaired for farm '%s'", vehicle:getFullName(), farm.name))
                    else
                        logMaintenance(vehicle, "no repair needed")
                        print(string.format("Vehicle '%s' is in excellent condition.", vehicle:getFullName()))
                    end
                end
            end
        end
    end
end

-- Handle individual commands (add money, repair vehicles, etc.)
local function handleCommand(command)
    print(string.format("Handling command: %s:%s", command.type, command.action))

    if command.type == "money" then
        local farmName = command.farmName
        local amount = command.amount
        local farm = g_farmManager:getFarmByName(farmName)

        if not farm then
            print(string.format("Error: Farm '%s' not found.", farmName))
            return
        end

        if command.action == "add" then
            farm.money = farm.money + amount
            print(string.format("Added %d to farm '%s'. New balance: %d", amount, farmName, farm.money))
        elseif command.action == "subtract" then
            farm.money = farm.money - amount
            print(string.format("Subtracted %d from farm '%s'. New balance: %d", amount, farmName, farm.money))
        else
            print(string.format("Error: Unknown action '%s' for type 'money'.", command.action))
        end
    elseif command.type == "repair" then
        local vehicleName = command.vehicleName
        local vehicle = g_currentMission:getVehicleByName(vehicleName)

        if not vehicle then
            print(string.format("Error: Vehicle '%s' not found.", vehicleName))
            return
        end

        local repairStatus = "already fully repaired"
        if vehicle:getRepairNeeds() > 0 then
            vehicle:repair()
            repairStatus = "repaired successfully"
        end

        logMaintenance(vehicle, repairStatus)
        print(string.format("Repair status for '%s': %s", vehicleName, repairStatus))
    elseif command.type == "maintenance" then
        local vehicleName = command.vehicleName
        local vehicle = g_currentMission:getVehicleByName(vehicleName)

        if not vehicle then
            print(string.format("Error: Vehicle '%s' not found.", vehicleName))
            return
        end

        local repairNeeds = vehicle:getRepairNeeds()
        local maintenanceStatus = repairNeeds > 0 and "requires maintenance" or "is in excellent condition"

        logMaintenance(vehicle, maintenanceStatus)
        print(string.format("Maintenance check for '%s': %s", vehicleName, maintenanceStatus))
    else
        print(string.format("Error: Unknown command type '%s'.", command.type))
    end
end

-- Process commands from JSON
local function processCommands()
    local filePath = getUserProfileAppPath() .. "modSettings/FarmSimSociety/commands.json"
    local commands = loadJsonFile(filePath)
    if commands then
        for _, command in ipairs(commands) do
            handleCommand(command)
        end
    else
        print("Error: No commands to process.")
    end
end

-- Event handler for money changes
local function onMoneyChanged(farmId)
    if farmId > 0 then
        local farm = g_farmManager:getFarmById(farmId)
        if farm then
            print(string.format("Money changed for farm '%s'. Current balance: %d", farm.name, farm.money))
            processCommands()
        else
            print(string.format("Error: Farm with ID '%d' not found.", farmId))
        end
    end
end

-- Subscribe to relevant events
local function subscribeToEvents()
    if g_currentMission and g_currentMission.messageCenter then
        g_currentMission.messageCenter:subscribe(MessageType.MONEY_CHANGED, onMoneyChanged)
        print("Subscribed to MONEY_CHANGED event.")
    else
        print("Error: Could not subscribe to events. Message center is nil.")
    end
end

-- Bind custom keypresses for repairs and maintenance
local function bindKeyActions()
    -- Example: Bind 'R' key for repair and 'M' key for maintenance
    local repairKey = InputBinding.KEY_R
    local maintenanceKey = InputBinding.KEY_M

    if InputBinding.isPressed(repairKey) then
        -- Trigger repair command for a specific vehicle (this can be customized)
        handleCommand({type = "repair", vehicleName = "Tractor1"})
    elseif InputBinding.isPressed(maintenanceKey) then
        -- Trigger maintenance check for a specific vehicle (this can be customized)
        handleCommand({type = "maintenance", vehicleName = "CombineHarvester1"})
    end
end

-- Auction system for used vehicles
local auctionDuration = 300  -- 5 minutes for auction duration
local auctionInterval = 5    -- Check the auction every 5 seconds
local auctionHouse = {}      -- Store auction information (vehicle details, bids, etc.)

-- Used vehicle list (this could be dynamically loaded or manually set)
local usedVehicles = {
    {name = "Tractor X1", startingBid = 20000, currentBid = 20000, highestBidder = nil, auctionEndTime = nil},
    {name = "Combine Y2", startingBid = 30000, currentBid = 30000, highestBidder = nil, auctionEndTime = nil},
}

-- Website API URL (replace with your actual website's API endpoint)
local websiteApiUrl = "https://farmsimsociety.com/api/auction"

-- Function to send auction data to the website
local function sendAuctionDataToWebsite(vehicle)
    -- Prepare the auction data as a table (convert to JSON)
    local auctionData = {
        vehicleName = vehicle.name,
        startingBid = vehicle.startingBid,
        currentBid = vehicle.currentBid,
        highestBidder = vehicle.highestBidder and vehicle.highestBidder.name or "None",
        auctionEndTime = vehicle.auctionEndTime,
        auctionStatus = os.time() > vehicle.auctionEndTime and "Ended" or "Active"
    }
    
    local jsonData = json.encode(auctionData)
    
    -- Send the data to the website via HTTP POST request
    local response = HttpRequest.post(websiteApiUrl, jsonData, "application/json")
    if response then
        print("Auction data sent to website successfully.")
    else
        print("Error: Could not send auction data to website.")
    end
end

-- Function to start an auction for a used vehicle
local function startAuction(vehicle)
    -- Set the auction end time
    vehicle.auctionEndTime = os.time() + auctionDuration
    print(string.format("Auction started for %s with starting bid of %d.", vehicle.name, vehicle.startingBid))
    
    -- Add the vehicle to the auction house
    auctionHouse[vehicle.name] = vehicle
    
    -- Send initial auction data to the website
    sendAuctionDataToWebsite(vehicle)
end

-- Function to handle placing a bid on a vehicle
local function placeBid(player, vehicleName, bidAmount)
    local vehicle = auctionHouse[vehicleName]
    
    if not vehicle then
        print("Error: Vehicle not found in auction.")
        return
    end

    -- Check if the auction is still active
    if os.time() > vehicle.auctionEndTime then
        print("Auction for " .. vehicle.name .. " has already ended.")
        return
    end

    -- If the bid is higher than the current bid, accept the new bid
    if bidAmount > vehicle.currentBid then
        vehicle.currentBid = bidAmount
        vehicle.highestBidder = player
        print(string.format("Player '%s' placed a bid of %d on %s.", player.name, bidAmount, vehicle.name))
        
        -- Send updated auction data to the website
        sendAuctionDataToWebsite(vehicle)
    else
        print("Bid must be higher than the current bid.")
    end
end

-- Function to finalize the auction once it ends
local function finalizeAuction(vehicle)
    if os.time() > vehicle.auctionEndTime then
        if vehicle.highestBidder then
            print(string.format("Auction for %s has ended. Winner: %s with bid %d.", vehicle.name, vehicle.highestBidder.name, vehicle.currentBid))
            -- Transfer the vehicle to the winning player and deduct money
            -- Example:
            -- vehicle.owner = vehicle.highestBidder
            -- vehicle.highestBidder.money = vehicle.highestBidder.money - vehicle.currentBid
        else
            print("Auction ended with no bids for " .. vehicle.name)
        end
        auctionHouse[vehicle.name] = nil  -- Remove the vehicle from the auction house

        -- Send auction finalized data to the website
        sendAuctionDataToWebsite(vehicle)
    end
end

-- Periodically check and finalize the auction
local function auctionTick()
    for _, vehicle in pairs(auctionHouse) do
        finalizeAuction(vehicle)
    end
end

-- Function to initialize the auction system
local function initAuctionSystem()
    -- Hide the default vehicle sale UI in the game
    hideUsedVehicleSaleUI()  -- Call your method to hide the used vehicle sale UI
    
    -- Start auctions for all used vehicles
    for _, vehicle in ipairs(usedVehicles) do
        startAuction(vehicle)
    end

    -- Start a periodic check for auction status
    addPeriodicFunction(auctionTick, auctionInterval)
end

-- Function to hide the default used vehicle sale UI in the game
local function hideUsedVehicleSaleUI()
    -- Assuming there's a system to hide the default used vehicle sale interface
    -- This can be game-specific, but for now, we assume we set the UI visibility to false
    g_gui:closeGui("UsedVehicleSaleUI")  -- Example function to close the UI
    print("Used Vehicle Sale UI hidden.")
end

-- Initialize auction system
initAuctionSystem()

-- Example commands (trigger auction or place bids)
-- Player places a bid on "Tractor X1" for 22000:
-- placeBid(player, "Tractor X1", 22000)
