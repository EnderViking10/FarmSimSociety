from sqlalchemy import Boolean, Column, Integer, String, ForeignKey, DateTime, Table
from flask_login import UserMixin
from datetime import datetime
from .db import Base

# Many-to-Many association table
user_servers = Table(
    "user_servers",
    Base.metadata,
    Column("user_id", Integer, ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    Column("server_id", Integer, ForeignKey("servers.id", ondelete="CASCADE"), primary_key=True),
)


class User(Base, UserMixin):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String)
    password = Column(String(120), nullable=False)
    discord_id = Column(Integer, nullable=False, index=True, unique=True)
    join_date = Column(DateTime, default=datetime.utcnow)
    is_admin = Column(Boolean, default=False)


class Bank(Base):
    __tablename__ = "bank"

    id = Column(Integer, primary_key=True, index=True)
    discord_id = Column(Integer, ForeignKey("users.discord_id"), nullable=False, unique=True)
    balance = Column(Integer, nullable=False, default=10000)


class Servers(Base):
    __tablename__ = "servers"

    id = Column(Integer, primary_key=True, index=True)
    ip = Column(String, nullable=False)
    name = Column(String, nullable=False)
    map = Column(String, nullable=False)
